#ifndef __ARAM_H__
#define __ARAM_H__
		
// Function prototypes
void write_aram(char *src, char *dst, int len);




#endif
